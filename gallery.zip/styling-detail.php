<?php
//include 'session.php';
ob_start();
?>

      <div class="styling-banner"></div>
       <div class="bg-traingle"></div>
        <div class="container">
   	     <div class="row">
   	      <div class="col-md-3"></div>
   	      <div class="col-md-6 center-boxs">
   	       <div class="styling-pic">
	 	   <img class="img-responsive" src="img/profile-img.jpg">
	 	   <span>Publish by<br> <strong>Loren ipsun</strong></span>
   		   </div>
   	      	<h3>Lorem Ipsum Simple Dummy Article</h3>
   	      	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam laoreet efficitur 
   	      	pharetra</p>
   	      	 <span><i class="fa fa-calendar" aria-hidden="true"></i> SEPT 3, 2017</span>
   	      	 <div class="margin15 clearfix"></div>
   	      	 <div class="line-account"></div>
   	      	 <div class="margin15"></div>
   	      	 <p>Share</p>
   	      	  <div class="socail-ul">
            	<ul>
				 <li><a href="#"><i class="fa fa-facebook"></i></a></li>
				   <li><a href="#"><i class="fa fa-twitter"></i></a></li>
					<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
				    </ul>
				     </div>
				     <div class="clearfix margin15"></div>
				     <div class="col-md-1"></div>
				      <div class="col-md-10 m-auto">
					   <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-1.jpg">
					   	    </div>
					     </div>
					    </div>
						    <div class="col-md-1"></div>
   	              </div> 
   	         <div class="clearfix margin15"></div>
   	          <p>Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor.</p>
   	       
   	           <div class="clearfix margin15"></div>
   	           <div class="line-account"></div>
   	            <div class="clearfix margin15"></div>
   	             <div class="col-md-6">
   	        	   <div class="row">
   	        		 <div class="col-md-6">
					   <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-1.jpg">
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
   	        		   </div>
 					<div class="col-md-6">
					  <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-1.jpg">
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
					 
   	        		</div>
			<div class="clearfix"></div>
 					<p>“Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vesti nunc maximus tempor.Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vesti nunc maximus tempor. ” </p>	
   	        	</div>
   	        </div>
   	        
   	        <div class="col-md-6">
   	        <p>“Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc maximus tempor. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc maximus tempor. ”</p>
   	             <div class="row">
   	        	    <div class="col-md-6">
					   <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-1.jpg">
					   	 
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
					 
   	        		</div>
				    <div class="col-md-6">
					 <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-1.jpg">
					   	 
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
   	        		   </div>
   	        	     </div>
   	               </div>
   	         
   	             <div class="clearfix margin20"></div>
   	                 <div class="clearfix margin-spc"></div>
   	             <div class="line-account"></div>
   	              <div class="head-button">More Style</div>
   	               <div class="clearfix margin20"></div>
   	           	    <div class="col-md-3 font-styles">
					 <div class="box-stlying-b">
					 	<img src="img/product-1.jpg">
					 	<span class="bottom-calender">
					 	<i class="fa fa-calendar" aria-hidden="true"></i> 
					 	<span class="space-box"> SEPT 3, 2017</span></span>
					 </div>
					 <h4>Lorem Ipsum Simple Dummy Article</h4>
					 <p>Lorem ipsum dolor sit amet, consectetur 
adipiscing elit. Nam laoreet efficitur pharetra</p>
					 </div>
                     <div class="col-md-3 font-styles">
					 <div class="box-stlying-b">
					 	<img src="img/product-1.jpg">
					 	<span class="bottom-calender">
					 	<i class="fa fa-calendar" aria-hidden="true"></i> 
					 	<span class="space-box"> SEPT 3, 2017</span></span>
					 </div>
					 <h4>Lorem Ipsum Simple Dummy Article</h4>
					 <p>Lorem ipsum dolor sit amet, consectetur 
adipiscing elit. Nam laoreet efficitur pharetra</p>
					 </div>
                        <div class="col-md-3 font-styles">
					 <div class="box-stlying-b">
					 	<img src="img/product-1.jpg">
					 	<span class="bottom-calender">
					 	<i class="fa fa-calendar" aria-hidden="true"></i> 
					 	<span class="space-box"> SEPT 3, 2017</span></span>
					 </div>
					 <h4>Lorem Ipsum Simple Dummy Article</h4>
					 <p>Lorem ipsum dolor sit amet, consectetur 
adipiscing elit. Nam laoreet efficitur pharetra</p>
					 </div>
 					<div class="col-md-3 font-styles">
					 <div class="box-stlying-b">
					 	<img src="img/product-1.jpg">
					 	<span class="bottom-calender">
					 	<i class="fa fa-calendar" aria-hidden="true"></i> 
					 	<span class="space-box"> SEPT 3, 2017</span></span>
					 </div>
					 <h4>Lorem Ipsum Simple Dummy Article</h4>
					 <p>Lorem ipsum dolor sit amet, consectetur 
adipiscing elit. Nam laoreet efficitur pharetra</p>
					 </div>
   	               </div>
   		         </div>
   		                <div class="relative">
   		         <div class="bg-traingle-bottom"></div>
   		         </div>
   		         
   		         <div class="text-center">
   		         	<button type="button" class="btn btn-login text-uppercase"> Explore more </button>
   		         </div>
   		         
     <div class="clearfix margin15"></div>
<?php
//Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Styling Detail";
$contentheader = "";
//Apply the template
include("template.php");
?>  


		