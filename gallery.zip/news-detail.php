<?php
//include 'session.php';
ob_start();
?>

<div class="full-bg-account">
 <div class="container">
	<div class="row">
	  <div class="skewed-bg relative">
	   <span><i class="fa fa-calendar" aria-hidden="true"></i> SEPT 3, 2017</span>
		</div>
		<div class="padd15">
		<div class="col-md-6"></div>
		<div class="col-md-6 ">
	    <div class="profile-box">
	 	 <img class="img-responsive" src="img/profile-img.jpg">
	 	  <span>Publish by<br> <strong>Loren ipsun</strong></span>
	 		</div>
	 	<div class="profile-box-heading">
	 	<h3>Lorem Ipsum Simple Dummy Article</h3>
	 	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam laoreet efficitur pharetra</p>
	  </div>
	 </div>
	 <div class="clearfix margin15"></div>
	 
	 <h4><strong>Vivamus consectetur ipsum eget turpis pulvinar, feugiat feugiat sapien pretium.</strong> </h4>
	 <p>Donec eu felis a justo euismod rutrum ut sit amet nisl. Ut quis enim consequat, sodales orci eget, interdum mi. Cras suscipit sapien a diam congue, quis pulvinar enim scelerisque. Sed sit amet nibh quis magna mollis rutrum. Interdum et malesuada fames ac ante ipsum primis in faucibus.
 Mauris mi urna, facilisis id convallis id, interdum at velit. Quisque luctus metus sed varius sagittis. Sed pulvinar, est at suscipit varius, leo nibh auctor nulla, ut semper massa justo eget erat. Praesent vitae dui ullamcorper, egestas dui nec, condimentum felis. Sed sed sagittis lacus. Praesent volutpat eget lectus vel eleifend. Duis eleifend eros ut lectus ultricies scelerisque. Proin ac tempor velit, vitae vestibulum lorem. Aliquam et volutpat odio. Nulla egestas, enim at maximus tempor, urna velit porttitor libero, sit amet maximus nisl arcu ultrices metus. Morbi euismod, metus vel sollicitudin lacinia, velit est fringilla enim, non ornare nisl sem a quam.</p>
 
 <p>Quisque cursus viverra imperdiet. Nullam nec turpis leo. Aenean dapibus blandit euismod. Donec eget lectus magna. Donec hendrerit leo ac nulla sodales, in aliquam nunc bibendum. Nullam posuere ipsum eu risus pharetra bibendum. Vestibulum egestas massa ac nunc rutrum, non luctus sapien sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi suscipit libero at fringilla rutrum. Suspendisse et nulla eu est rutrum eleifend. </p>
 <div class="margin15 clearfix"></div>
   <div class="row">
    <div class="col-md-5">
 	 <div class="quotes-news">
 	 <div class="quotes-fa"><i class="fa fa-quote-left" aria-hidden="true"></i></div>
 	  <p>Lorem ipsum dolor sit amet, consec tetur adipiscing elit. Aenean ac semper turpis. Vestibulum tristique libero nec eros rhoncus, id luctus arcu aliquam. Dictum urna quis, rutrum magna. In feugiat, massa sit amet varius posuere, odio sapien mattis est, ut accumsan nisi arcu non dolor. Donec viverra.
 	em ipsum dolor sit amet, consec tetur adipiscing elit. Aenean ac semper turpis. Vestibulum tristique libero nec eros rhoncus, id luctus arcu aliquam. Dictum urna quis, rutrum magna. In feugiat, massa sit amet varius posuere, odio sapien mattis es
 	t amet, consec tetur adipiscing elit. Aenean ac semper turpis. Vestibulum tristique libero nec eros rhoncus, id luctus arcu aliquam. Dictum urna quis, rutrum magna. In feugiat, massa sit amet varius posuere, odio sapien mattis es
     </p>	
     </div>
    </div>
    <div class="margin15 visible-xs visible-sm"></div>
    <div class="col-md-7 text-center">
    	<img class="img-responsive m-auto" src="img/new-detail-img.jpg">
    </div>
   </div>
  <div class="clearfix margin15"></div>
   <h4><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ac semper turpis.</strong></h4>
   <p>Vestibulum tristique libero nec eros rhoncus, id luctus arcu aliquam. Vivamus finibus, dui id ultrices eleifend, lacus est consequat dolor, nec semper turpis dolor id dui. Suspendisse eu leo fringilla, dictum urna quis, rutrum magna. In feugiat, massa sit amet varius posuere, odio sapien mattis est, ut accumsan nisi arcu non dolor. Donec viverra. Nullam blandit, elit a feugiat condimentum, metus nibh rhoncus nunc, eu ullamcorper ligula nisi et velit. Quisque gravida ex sit amet dui tempor suscipit. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor. Sed vulputate sapien lacinia, ullamcorper nisi ut, gravida turpis.</p>
   <p>
Sed suscipit nisi pretium finibus porttitor. Proin varius malesuada neque, sed vehicula ipsum cursus sed. Cras gravida consequat sem mattis viverra. Aenean eleifend viverra fermentum. Maecenas sem nibh, iaculis vitae hendrerit eget, rhoncus pharetra felis. </p>
<p>Vivamus consectetur ipsum eget turpis pulvinar, feugiat feugiat sapien pretium. Donec eu felis a justo euismod rutrum ut sit amet nisl. Ut quis enim consequat, sodales orci eget, interdum mi. Cras suscipit sapien a diam congue, quis pulvinar enim scelerisque. Sed sit amet nibh quis magna mollis rutrum. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
<div class="clearfix margin15"></div>
	<div class="row">
	  <div class="col-md-5">
		<img class="img-responsive" src="img/new-detail-img2.jpg">
	 </div>
	  <div class="col-md-7">
	  	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ac semper turpis. Vestibulum tristique libero nec eros rhoncus, id luctus arcu aliquam. Vivamus finibus, dui id ultrices eleifend, lacus est consequat dolor, nec semper turpis dolor id dui. Suspendisse eu leo fringilla, dictum urna quis, rutrum magna. In feugiat, massa sit amet varius posuere, odio sapien mattis est, ut accumsan nisi arcu non dolor. Donec viverra. Nullam blandit, elit a feugiat condimentum, metus nibh rhoncus nunc, eu ullamcorper ligula nisi et velit. Quisque gravida ex sit amet dui tempor suscipit. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor. Sed vulputate sapien lacinia, ullamcorper nisi ut, gravida turpis.</p>
	  	<p>Sed suscipit nisi pretium finibus porttitor. Proin varius malesuada neque, sed vehicula ipsum cursus sed. Cras gravida consequat sem mattis viverra. Aenean eleifend viverra fermentum. Maecenas sem nibh, iaculis vitae hendrerit eget, rhoncus pharetra felis. </p>
	  		  	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ac semper turpis. Vestibulum tristique libero nec eros rhoncus, id luctus arcu aliquam. Vivamus finibus, dui id ultrices eleifend, lacus est consequat dolor, nec semper turpis dolor id dui. Suspendisse eu leo fringilla, dictum urna quis, rutrum magna. In feugiat, massa sit amet varius posuere, odio sapien mattis est, ut accumsan niid dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor. Sed vulputate sapien lacinia, ullamcorper nisi ut, gravida turpis.</p>
	  </div>
    </div>
    <div class="clearfix margin15"></div>
    <p>Vivamus consectetur ipsum eget turpis pulvinar, feugiat feugiat sapien pretium. Donec eu felis a justo euismod rutrum ut sit amet nisl. Ut quis enim consequat, sodales orci eget, interdum mi. Cras suscipit sapien a diam congue, quis pulvinar enim scelerisque. </p>
    <p>Sed sit amet nibh quis magna mollis rutrum. Interdum et malesuada fames ac ante ipsum primis in faucibus. Cras gravida consequat sem mattis viverra. Aenean eleifend viverra fermentum. Maecenas sem nibh, iaculis vitae hendrerit eget, rhoncus pharetra felis. </p>
	  </div>
     </div>
    </div>  
    </div>    
<?php
//Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "News Detail";
$contentheader = "";
//Apply the template
include("template.php");
?>  




		