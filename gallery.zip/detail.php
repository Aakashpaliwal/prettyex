<?php
//include 'session.php';
ob_start();
?>

   <div class="margin15"></div>
      <div class="container">
    	<div class="row">
    	  <div class="col-md-9 btn-detail">
    		<span><button type="button" class="btn btn-login"><i class="fa fa-shopping-basket"
    		 aria-hidden="true"></i> Buy Now </button></span>
    		  <span><button type="button" class="btn btn-cart"> 
    		<i class="fa fa-shopping-cart" aria-hidden="true"></i> Add to Cart </button></span>
    		 		
    		 <span><button type="button" class="btn btn-love"> 
    		 <i class="fa fa-heart" aria-hidden="true"></i>  Love it </button></span>
    		</div>
    		<div class="margin15 visible-xs"></div>
    		  <div class="col-md-3 text-right">
    			 <span id="half1"></span>
    		 	   <span class="rate-t"> Rating 4.0</span>
    		   </div>
     	     </div>
     	   <div class=" margin15"></div>
         <div class="line-b"></div>
          </div>
        
       <div class="clearfix"></div>
        <div class="margin-spc"></div>
          <div class="container">
       	   <div class="row">
       		<div class="col-md-5">
       		<div class="product-detail-h">
       		<div class="bord crossfd">
				<img src="img/product-3.jpg"></img>
				</div>
				</div>
             </div>
           <div class="col-md-7 detail-font">
           	<h3>Product Discription- K24166EW</h3>
           	<p>Red floral embroidered choli, has a halter-neck with tie-up and pom-pom detail, button closures on the back, flared hem Red net lehenga, has an elasticated waistband, tie-up detail with pom-pom detail, flared hem, attached lining Red net dupatta, has pom-pom detail at the ends Red floral embroidered</p>
  <div class="margin15"></div>
  <div class="row">
   <div class="col-md-3 col-xs-4 form-group">
     <label for="">Size : </label>
      <select class="form-control" id="exampleFormControlSelect1">
      <option>1-9</option>
      <option>8-10</option>
      <option>3</option>
     </select>
   </div>
  
  <div class="col-md-3 col-xs-8 btn-top">
  	<button type="button" class="btn btn-chart"> Size Chart </button>
     </div>
     </div>
    <div class="clearfix"></div>
      <h4>colors</h4>
       <div class="color">
     	 <span class="color-box"></span>
     	 <span class="color-box2"></span>
     	 <span class="color-box3"></span>
         <span class="color-box4"></span>
     	 <span class="color-box5"></span>
     	 </div>
     	  <div class="margin15"></div>
     	  <img src="img/limit-img.png">
     	   <h4>Share Us on </h4>
     	     <div class="socail-ul">
            	<ul>
				 <li><a href="#"><i class="fa fa-facebook"></i></a></li>
				   <li><a href="#"><i class="fa fa-twitter"></i></a></li>
					<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
				    </ul>
				    </div>
                </div> 
             </div>
          </div>
	   </div>
     <div class="margin-spc"></div>
       <div class="container">
     	  <div class="row">
     	    <div class="pera-center text-center">
     		<h2>Style Statement</h2>
     		<p>In a need-now warm hue and updated style and silhouette, the Olive Zipped Wrap Dress makes a strong case of the perfect dress to own at work and on the weekends. Work it 9-to-5 with nude heels and minimal jewels. Take it for that party with gilded heels or flats and a statement necklace.
     		 on the weekends. Work it 9-to-5 with nude heels and minimal jewels. Take it for that party with gilded heels or flats and a s</p>
     		</div>
     	</div>
     </div>
             <div class="margin-spc"></div>
               <div class="detail-bg-pink">
          	     <div class="container">
          		   <div class="row">
          		     <div class="col-md-3">
          		 	   <div class="left-b">
          		 		<h2>Fabric Detail</h2>
          		 		<p><i class="fa fa-chevron-right"></i> Soft natural Cotton with Natural 
          		 		Colors</p>
          		 		<p><i class="fa fa-chevron-right"></i> 70 % Cotton with 30 % Polyester mix</p>
          		 		<p><i class="fa fa-chevron-right"></i> 70 % Cotton with 30 % Polyester mix</p>
          		 		<p><i class="fa fa-chevron-right"></i> Synthatic Leather Attachment </p>
          		 		<p><i class="fa fa-chevron-right"></i> No Pins for Skin </p>	
          		 	  </div>
          		    </div>
          		    
          		   	   <div class="col-md-5">
          		    	 <div class="product-detail-b">
					      <div class="detail-outline">
					   	   <img class="img-responsive" src="img/prod.jpg">
					   	   <div class="middle">
					   	   <div class="inner-box">
				   	   <span>
					   	   <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i> Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i> Add cart</button>
					   		 </span>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
          		   	 </div>
          		   	 
          		   	 <div class="col-md-4">
          		   	 	<div class="right-b">
          		   	 	<h2>Maintain & Care</h2>
          		 		<p><i class="fa fa-chevron-right"></i> Dry Clean Only</p>
          		 		<p><i class="fa fa-chevron-right"></i> Gentle Iron, Dry using Hanger</p>
          		 		<p><i class="fa fa-chevron-right"></i> Gentle Iron, Dry using Hanger, </p>
          		 		<p><i class="fa fa-chevron-right"></i> Item#12, Item 34 </p>
          		   	 	</div>
          		   	 </div>
          		 </div>
          	    </div>
              </div>
              <div class="margin-spc"></div>
               <div class="container">
              	 <div class="row">
              	   <div class="text-center statement">
              		<h2>Fashion Statement</h2>
              	      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam laoreet efficitur
              	     pharetra</p>
              	    
              	      <div class="col-md-5">
              	     	 <div class="product-detail-b">
					      <div class="detail-outline">
					   	   <img class="img-responsive" src="img/prod.jpg">
					   	   <div class="middle">
					   	   <div class="inner-box">
				   	   <span>
					   	   <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i> Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i> Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
              	     </div>
              	     <div class="col-md-5 detail-perag">
              	     	<p>“Fashion is what you’re offered four times a year by designers. 
              	     	And style is what you choose.” </p>
              	     	<span>- Lauren Hutton</span>
              	     </div>
              	     <div class="col-md-2"></div>
              	     <div class="clearfix"></div>
              	       <div class="col-md-5 detail-perag">
              	     	<p>“Fashion is what you’re offered four times a year by designers. 
              	     	And style is what you choose.” </p>
              	     	<span> - Lauren Hutton</span>
              	       </div>
              	       <div class="col-md-5">
              	     	 <div class="product-detail-b">
					      <div class="detail-outline">
					   	   <img class="img-responsive" src="img/prod.jpg">
					   	   <div class="middle">
					   	   <div class="inner-box">
					   	   <span>
					   	   <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i> Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i> Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
              	     </div>
              	     <div class="col-md-2"></div>
              	     
              		</div>
              	  </div>
               </div>
      <div class="margin-spc"></div>
    <div class="bg-testimonail">
                	 <div class="container">
                		<div class="row">
                		 <div class="text-center white">
					      <h4>HandPicked For You</h4>
					       <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
					    	 <br>Nam laoreet efficitur pharetra</p>
			                 </div>
			    <div class="margin-spc"></div>
			<div id="testimonial4" class="carousel slide testimonial4_indicators testimonial4_control_button thumb_scroll_x swipe_x" data-ride="carousel" data-pause="hover" data-interval="5000" data-duration="2000">
	
		<div class="carousel-inner" role="listbox">
			<div class="item active">
                <div class="box-full-testi">
                  <div class="quot1">
                  	 <i class="fa fa-quote-right" aria-hidden="true"></i>
                  </div>
                     <div class="quot2">
                  	 <i class="fa fa-quote-right" aria-hidden="true"></i>
                  </div>
                
			      <div class="col-md-1 col-xs-1"></div>
			      	<div class="col-md-3 col-xs-12 text-center">
			      	  <div class="outline">
			      		<img src="img/test-img.jpg">
			      		</div>
			      	</div>
			      	
			      	<div class="col-md-8 col-xs-12">
			      	<p>
			      	Lorem Ipsum is simply dummy text of the printing and typesetting industry.
					Lorem Ipsum has been the industry's standard dummy text.
					</p>
					<span>
					 <img src="img/dp.png"> 
					 </span>
					<span class="inline-b"><p>Lorem Ipsum <br> Designer</p> </span>
			      </div>
			     </div>
			</div>
			<div class="item">
			  <div class="box-full-testi">
                  <div class="quot1">
                  	 <i class="fa fa-quote-right" aria-hidden="true"></i>
                  </div>
                     <div class="quot2">
                  	 <i class="fa fa-quote-right" aria-hidden="true"></i>
                  </div>
                
			      <div class="col-md-1 col-xs-1"></div>
			      	<div class="col-md-3 col-xs-12 text-center">
			      	  <div class="outline">
			      		<img src="img/test-img.jpg">
			      		</div>
			      	</div>
			      	
			      	<div class="col-md-8 col-xs-12">
			      	<p>
			      	Lorem Ipsum is simply dummy text of the printing and typesetting industry.
					Lorem Ipsum has been the industry's standard dummy text.
					</p>
					<span>
					 <img src="img/dp.png"> 
					 </span>
					<span class="inline-b"><p>Lorem Ipsum <br> Designer</p> </span>
			      </div>
			     </div>

			</div>

		</div>
		<a class="left carousel-control" href="#testimonial4" role="button" data-slide="prev">
			<span class="fa fa-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#testimonial4" role="button" data-slide="next">
			<span class="fa fa-chevron-right"></span>
		</a>
	</div>
			       
                			   </div>
                	         </div>
                           </div>
                    <div class="clearfix"></div>
     
		  <div class="detail-slider">
	         <div class="container">
		        <div class="row">
		        <div class="text-center white">
					      <h4>Similar Products</h4>
					       <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
					    	 <br>Nam laoreet efficitur pharetra</p>
			                 </div>
		         <div class="margin-spc"></div>
		           <div class="owl-carousel owl-theme">
					  <div class="item">
					  <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-2.jpg">
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
					    </div>
					    
					   <div class="item">
					   <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-2.jpg">
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
					    </div>
					    
					    <div class="item">
					  <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-2.jpg">
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
					    </div>
					    
					   <div class="item">
					   <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-2.jpg">
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	  <p>Lorem Ipsum Simple</p>
					   	  <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	 </div>
					    </div>
					    
					   <div class="item">
					   <div class="white-box-product">
					    <div class="outline-hover">
					   	 <img src="img/product-2.jpg">
					   	  <div class="middle">
					   	   <div class="inner-box">
					   	    <div class="heart-b"><i class="fa fa-heart-o" aria-hidden="true"></i>
					   	    Love it</div>
					   	   <span>
					   	       <a href="detail.php">
					   	   	<button type="button" class="btn btn-login">
					   		<i class="fa fa-shopping-basket" aria-hidden="true"></i><br>
					   		Buy Now</button>
					   		</a>
					   		    </span>
					   		   <span>
					   	   	<button type="button" class="btn btn-addcart">
					   		<i class="fa fa-shopping-cart" aria-hidden="true"></i><br>
					   		Add cart</button>
					   		 </span>
					   		</div>
					   	   </div>
					   	    </div>
					     </div>
					     <div class="clearfix"></div>
						 <div class="bottom-box">
					   	   <p>Lorem Ipsum Simple</p>
					   	   <p><i class="fa fa-inr" aria-hidden="true"></i> 500.00</p>
					   	   </div>
					       </div>
					       </div>
			
		  </div>
	   </div>
	</div>     
     
<?php
//Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Detail";
$contentheader = "";
//Apply the template
include("template.php");
?>  


<script src="js/jquery.raty.min.js"></script>
<script>
      $('#half1').raty({
        half: true,
        start: 3.3

        });
</script>

<script>
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:15,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:1,
            nav:false
        },
        1000:{
            items:4,
            nav:true,
            loop:false
        }
    }
})
</script>

<script>
	$(document).ready(function(){
// invoke the carousel
    $('#myCarousel').carousel({
      interval: 3000
    });

});
</script>
	