   				<div class="footer-bg-color">
	             <div class="container">
	              <div class="row">
	               <div class="margin-spc"></div>
	                <div class="text-center">
	              	 <img src="img/logo2.svg">
	              	  <div class="margin15"></div>
	              	 <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been <br> the industry's standard dummy text ever since the when an unknown printer took
	              	  a galley make. </p>
	                  </div>
	                  <div class="margin-spc"></div>
	                   <div class="col-md-3">
	                   	 <img src="img/logo-white.png">
	                  	  <div class="margin15"></div>
	                       <div class="row">
	                  		<div class="col-md-2">
	                  		<img src="img/location.svg">
	                  		</div>
	                  		<div class="col-md-10">
	                  		  <p>Lorem Ipsum is simply dummy text of the typesetting industry.</p>	
	                  		</div>
	                  		<div class="clearfix"></div>
	                  		 <div class="col-md-2">
	                  			<img src="img/call-foot.svg">
	                  		</div>
	                  		<div class="col-md-10">
	                  		  <p>(123) 456-7890</p>	
	                  		</div>
	                  		 <div class="clearfix"></div>
	                  		 <div class="col-md-2">
	                  			<img src="img/mail-foot.svg">
	                  		</div>
	                  		<div class="col-md-10">
	                  		  <p>info@prettyex.com</p>	
	                  		</div>
	                  	  </div>
	                    </div>
	                   
	                   <div class="col-md-3">
	                   	 <h4>useful Links</h4>
	                   	 <div class="row">
	                   	 <div class="col-md-6">
	                   	   <div class="footer-ul">
	                   	 	 <ul>
	                   	 	    <li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> Pretty Me!! </a></li>
	                   	 		<li><a href="#"> <i class="fa fa-chevron-right" aria-hidden="index.php"></i> PrettyEx </a></li>
	                   	 		<li><a href="#"> <i class="fa fa-chevron-right" aria-hidden="true"></i> Exclusive</a></li>
	                   	 		<li><a href="brand.php"><i class="fa fa-chevron-right" aria-hidden="true"></i> The Brand </a></li>
	                   	 		<li><a href="news.php"> <i class="fa fa-chevron-right" aria-hidden="true"></i> News  </a></li>
	                   	 		<li><a href="#"> <i class="fa fa-chevron-right" aria-hidden="true"></i> Gallery </a></li>
	                   	 	</ul>
	                   	   </div>
	                   	 </div>
	                   	 <div class="col-md-6">
	                   	   <div class="footer-ul">
	                   	 	 <ul>
	                   	 	<li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> FAQ</a></li>
	                   	 	<li><a href="#"> <i class="fa fa-chevron-right" aria-hidden="true"></i> Terms Of Use </a></li>
	                   	 	<li><a href="#"> <i class="fa fa-chevron-right" aria-hidden="true"></i> Track Orders</a></li>
	                   	 	<li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> Shipping </a></li>
	                   	 	<li><a href="#"> <i class="fa fa-chevron-right" aria-hidden="true"></i> Cancellation </a></li>
	                             	 	</ul>
	                   	   </div>
	                   	 </div>
	                   	 </div>
	                   </div>
	                   
	                 <div class="col-md-3">
	                   <h4>Feature</h4>
	                   	 <div class="footer-ul">
	                   	  <ul>
	                   	 <li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> Lorem Ipsum is simply 
	                   	 	  dummy</a></li>
	                   	 <li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> Lorem Ipsum is simply 
	                   	 	  dummy</a></li>
	                   	 	  <li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> Lorem Ipsum is simply 
	                   	 	  dummy</a></li>
	                   	 	  <li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> Lorem Ipsum is simply 
	                   	 	  dummy</a></li>
	                   	 	  <li><a href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i> Lorem Ipsum is simply 
	                   	 	  dummy</a></li>	  
	                   	 	
	                          </ul>
	                   	   </div>
	                   	 </div>
	                   	 
	                   <div class="col-md-3">
	                    <h4>Newsletter</h4>
	                     <p>Lorem ipsum dolor sit amet dolor consectetur adipiscing elit. </p>
	                      <div class="input-group mb-2 mr-sm-2 mb-sm-0">
						  <input type="text" class="form-control border0" id="" placeholder="Email">
						    <div class="input-group-addon border0 input-bg white"> Go</div>
						   </div>
	                    </div>
	                  
	                    <div class="margin-spc clearfix hidden-xs hidden-sm"></div>
	                     <div class="margin15 clearfix visible-xs visible-sm"></div>
	                    <div class="grey-line-footer"></div>
						 <section class="social">
						 <a href="" class="icon fb"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						 <a href="" class="icon fb"><i class="fa fa-twitter" aria-hidden="true"></i></a>
						 <a href="" class="icon fb"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						  <a href="" class="icon fb"><i class="fa fa-google-plus" aria-hidden="true"></i></i></a>
						   <a href="" class="icon fb"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
						</section>
						<div class="clearfix"></div>
	                    <div class="grey-line-footer"></div>
	                 </div>
			         	         
					   <div class=" margin-spc"></div>
						<p class="text-center foot-t-c"> 
						2017 © PrettyEX - All rights reserved</p>
								 </div>
									</div>