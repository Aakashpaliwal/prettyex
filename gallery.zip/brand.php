<?php
//include 'session.php';
ob_start();
?>


 <div id="first-slider">
    <div id="carousel-example-generic" class="carousel slide carousel-fade">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            <li data-target="#carousel-example-generic" data-slide-to="3"></li>
        </ol>
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <!-- Item 1 -->
            <div class="item active slide1">
                <div class="row">
                   <div class="container">
                     <div class="col-md-12 text-center">
                        <img src="img/long-limit-img.png">        
                      </div>
                   </div>
                 </div>
               </div> 
            <!-- Item 2 -->
            <div class="item slide2">
    			<div class="row">
                   <div class="container">
                     <div class="col-md-12 text-center">
                        <img src="img/long-limit-img.png">        
                      </div>
                   </div>
                 </div>
            </div>
            <!-- Item 3 -->
            <div class="item slide3">
    			<div class="row">
                   <div class="container">
                     <div class="col-md-12 text-center">
                        <img src="img/long-limit-img.png">        
                      </div>
                   </div>
                 </div>
            </div>
            <!-- Item 4 -->
            <div class="item slide4">
    			<div class="row">
                   <div class="container">
                     <div class="col-md-12 text-center">
                        <img src="img/long-limit-img.png">        
                      </div>
                   </div>
                 </div>
            </div>
            <!-- End Item 4 -->
    
        </div>
        <!-- End Wrapper for slides-->

    </div>
</div>

   <div class="bg-brand1">
  <div class="container">
    <div class="row">
	 <div class="col-md-5">
	  <div class="text-style">
	 	<h4>Sample Text <br> Needs to <br>
       <span class="color-texts"> be Editiable </span></h4>
      </div>
	 </div>	
	  <div class="col-md-7">
	   <div class="text-style">
	    <p>Donec molestie Fusce sed ipsum eget enim fermentum aliquet ia sapien. posuere diam sed In et nunc leo. Fusce sed ipsum eget enim fermentum aliquet ia sapien. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor.</p>
	  </div>
	 </div>	
    </div>
   </div>
   </div>
   
     <div class="bg-brand2">
  <div class="container">
    <div class="row">
	
	  <div class="col-md-7">
	   <div class="text-style">
	    <p>Donec molestie Fusce sed ipsum eget enim fermentum aliquet ia sapien. posuere diam sed In et nunc leo. Fusce sed ipsum eget enim fermentum aliquet ia sapien. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor.</p>
	  </div>
	 </div>
       <div class="col-md-5">
	  <div class="text-style">
	 	<h4>Sample Text <br> Needs to <br>
       <span class="color-orange"> be Editiable </span></h4>
      </div>
	 </div>		
      </div>
    </div>
   </div>
 
       <div class="bg-brand3">
  <div class="container">
    <div class="row">
	 <div class="col-md-5">
	  <div class="text-style">
	 	<h4  class="color-blue">Sample Text <br> Needs to <br>
        be Editiable </span>
      </div>
	 </div>	
	  <div class="col-md-7">
	   <div class="text-style">
	    <p>Donec molestie Fusce sed ipsum eget enim fermentum aliquet ia sapien. posuere diam sed In et nunc leo. Fusce sed ipsum eget enim fermentum aliquet ia sapien. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor.</p>
	  </div>
	 </div>	
    </div>
   </div>
   </div>

        <div class="bg-brand4">
   <div class="container">
    <div class="row">
     <div class="col-md-7">
	   <div class="text-style">
	    <p>Donec molestie Fusce sed ipsum eget enim fermentum aliquet ia sapien. posuere diam sed In et nunc leo. Fusce sed ipsum eget enim fermentum aliquet ia sapien. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor.</p>
	  </div>
	 </div>	
	 <div class="col-md-5">
	  <div class="text-style">
	 	<h4>Sample Text <br> Needs to <br>
       <span class="color-texts"> be Editiable </span></h4>
      </div>
	 </div>	
	 
    </div>
   </div>
   </div>

         <div class="bg-brand5">
  <div class="container">
    <div class="row">
	 <div class="col-md-5">
	  <div class="text-style">
	 	<h4 >Sample Text <br> Needs to <br>
       <span  class="color-orange"> be Editiable </span>
      </div>
	 </div>	
	  <div class="col-md-7">
	   <div class="text-style">
	    <p>Donec molestie Fusce sed ipsum eget enim fermentum aliquet ia sapien. posuere diam sed In et nunc leo. Fusce sed ipsum eget enim fermentum aliquet ia sapien. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor.</p>
	  </div>
	 </div>	
    </div>
   </div>
   </div>

          <div class="bg-brand6">
   <div class="container">
    <div class="row">
     <div class="col-md-7">
	   <div class="text-style">
	    <p>Donec molestie Fusce sed ipsum eget enim fermentum aliquet ia sapien. posuere diam sed In et nunc leo. Fusce sed ipsum eget enim fermentum aliquet ia sapien. Mauris sodales nulla enim, porta eleifend massa vulputate a. Sed vestibulum commodo turpis et finibus. Nunc mauris libero, lobortis non libero et, gravida congue mauris. Nunc porta sem id dui maximus tempor. Phasellus sed gravida quam, rhoncus luctus tortor.</p>
	  </div>
	 </div>	
	 <div class="col-md-5">
	  <div class="text-style">
	 	<h4>Sample Text <br> Needs to <br>
       <span class="color-texts"> be Editiable </span></h4>
      </div>
	 </div>	
	 
    </div>
   </div>
   </div>

<div class="video-banner">
  <div class="container">
	<div class="row">
	<div class="col-md-2"></div>
		<div class="col-md-8">
	 <iframe width="100%" height="410" frameborder="0" src="https://www.youtube.com/embed/XGSy3_Czz8k">
      </iframe>
      </div>
      <div class="col-md-2"></div>
	</div>
  </div>
</div>


   
   

          
<?php
//Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Brand";
$contentheader = "";
//Apply the template
include("template.php");
?>  

<script>
	(function( $ ) {

    //Function to animate slider captions 
	function doAnimations( elems ) {
		//Cache the animationend event in a variable
		var animEndEv = 'webkitAnimationEnd animationend';
		
		elems.each(function () {
			var $this = $(this),
				$animationType = $this.data('animation');
			$this.addClass($animationType).one(animEndEv, function () {
				$this.removeClass($animationType);
			});
		});
	}
	
	//Variables on page load 
	var $myCarousel = $('#carousel-example-generic'),
		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
		
	//Initialize carousel 
	$myCarousel.carousel();
	
	//Animate captions in first slide on page load 
	doAnimations($firstAnimatingElems);
	
	//Pause carousel  
	$myCarousel.carousel('pause');
	
	
	//Other slides to be animated on carousel slide event 
	$myCarousel.on('slide.bs.carousel', function (e) {
		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
		doAnimations($animatingElems);
	});  
    $('#carousel-example-generic').carousel({
        interval:1000,
        pause: "false"
        autoplay: true,
    });
	
})(jQuery);	

</script>

		